import Cocoa

// MARK: - Fruits

protocol Fruit: Equatable {
    var size: Int { get }
}

struct Apple: Fruit {
    let size: Int
}

struct Orange: Fruit {
    let size: Int
}

func ==(lhs: Apple, rhs: Apple) -> Bool {
    
    return lhs.size == rhs.size
}

func ==(lhs: Orange, rhs: Orange) -> Bool {
    
    return lhs.size == rhs.size
}

protocol Saucable {
    
    func sauceWith<T: Saucable>(evenMoreOf: T)
}

struct Saucer {
    
    func sauce<T: protocol<Fruit, Saucable>, U: protocol<Fruit, Saucable>>(one: T, other: U) {
        one.sauceWith(other)
    }
}

extension Apple: Saucable {
    
    func sauceWith<T: Saucable>(evenMoreOf: T) {
        // do something cool
    }
}

protocol Peelable {
    typealias FruitPult: Fruit
    
    func peel() -> FruitPult
}

struct OrangePulp: Fruit {
    let size: Int
}

func ==(lhs: OrangePulp, rhs: OrangePulp) -> Bool {
    
    return lhs.size == rhs.size
}

extension Orange: Peelable {
    
    func peel() -> OrangePulp {
        return OrangePulp(size: size)
    }
}

extension OrangePulp: Saucable {
    
    func sauceWith<T: Saucable>(evenMoreOf: T) {
        // mushed orange? Or orange-apple-mush?
    }
}

extension Orange: Saucable {
    
    func sauceWith<T : Saucable>(evenMoreOf: T) {
        evenMoreOf.sauceWith(peel())
    }
}

let saucer = Saucer()
saucer.sauce(Orange(size: 12).peel(), other: Orange(size: 10).peel())
saucer.sauce(Orange(size: 12).peel(), other: Apple(size: 10))


// MARK: - Values (Brent's Stuff)

protocol Value: Equatable {}

protocol Addable {
    func add(other: Self) -> Self
}

protocol Coercible {
    func coerce(with: Self)
}

struct IntValue: Value, Addable {
    
    let value: Int
    
    func add(other: IntValue) -> IntValue {
        
        let result = value + other.value
        return IntValue(value: result)
    }
}

func ==(lhs: IntValue, rhs: IntValue) -> Bool {
    
    return lhs.value == rhs.value
}


func valueByAddingValue​s<T: protocol<Value, Addable>>(one: T, other: T) -> T {
    
    return one.add(other)
}

